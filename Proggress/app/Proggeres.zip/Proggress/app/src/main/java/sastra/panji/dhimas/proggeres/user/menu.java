package sastra.panji.dhimas.proggeres.user;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import sastra.panji.dhimas.proggeres.R;

public class menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
    }
}
