package sastra.panji.dhimas.proggeres.user;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import sastra.panji.dhimas.proggeres.R;

public class Login extends AppCompatActivity {

    EditText username, password;
    Button login;
    ProgressBar loading;

    private static String URL = "https://dc5279de1f94.ngrok.io/api/peternak/auth/login";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        getCurrentFirebaseToken();

        username = findViewById(R.id.lg_username);
        password = findViewById(R.id.lg_password2);
        login = findViewById(R.id.btn_login);
        loading = findViewById(R.id.loading);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Username = username.getText().toString().trim();
                String Password = password.getText().toString().trim();

                if (!Username.isEmpty() || !Password.isEmpty()) {

                    Login(Username, Password);
                } else {
                    username.setError("Masukkan Username");
                    password.setError("Masukkan Password");
                }
            }
        });


    }

    private void Login(final String user, final String pass) {
        loading.setVisibility(View.VISIBLE);
        login.setVisibility(View.GONE);
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    Log.d("Response", response.toString());
                    JSONObject object = new JSONObject(response);
                    Boolean succes = object.getBoolean("status");

                    if (succes) {
                        String id = object.getString("id");
                        loading.setVisibility(View.GONE);
                        Toast.makeText(Login.this, "Berhasil Login, ID anda = " + id, Toast.LENGTH_LONG).show();
                        //Toast.makeText(Login.this, response, Toast.LENGTH_LONG).show();

                    } else {
                        loading.setVisibility(View.GONE);
                        Toast.makeText(Login.this, "Login Gagal!", Toast.LENGTH_LONG).show();

                    }

                } catch (JSONException e) {
                    loading.setVisibility(View.GONE);

                    login.setVisibility(View.VISIBLE);
                    Toast.makeText(Login.this, "Error " + e.toString(), Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                loading.setVisibility(View.GONE);
                login.setVisibility(View.VISIBLE);
                Toast.makeText(Login.this, "Error " + error.toString(), Toast.LENGTH_LONG).show();


            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("email", user);
                params.put("password", pass);
                return params;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();


                params.put("Accept", "application/json");

                return params;
            }

        };

        requestQueue.add(stringRequest);
    }

    private void getCurrentFirebaseToken() {
        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                    @Override
                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
                        if (!task.isSuccessful()) {
                            Log.w("TAG", "getInstanceId failed", task.getException());
                            return;
                        }

                        // Get new Instance ID token
                        String token = task.getResult().getToken();
                        Log.e("currentToken fcm", token);

                        // Log and toast
//                        String msg = getString(R.string.msg_token_fmt, token);
//                        Log.d("TAG", msg);
                        Toast.makeText(Login.this, token, Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
